package com.lsi.lab4.controller.request;

public record StudentRequest (
        String firstName,
        String lastName
){ }
